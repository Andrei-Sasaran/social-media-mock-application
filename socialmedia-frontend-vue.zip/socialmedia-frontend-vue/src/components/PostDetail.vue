<template>
  <div>
    <h2>{{ post.title }}</h2>
    <p>{{ post.content }}</p>

    <hr />

    <h3>Comments</h3>
    <div v-if="comments.length">
      <ul>
        <li v-for="comment in comments" :key="comment.id">
          {{ comment.content }}
        </li>
      </ul>
    </div>
    <div v-else>
      <p>No comments yet.</p>
    </div>

    <hr />

    <!-- Afișăm butonul de ștergere doar dacă userul logat este autorul -->
    <button v-if="isAuthor" @click="deletePost">Delete Post</button>
    
    <div v-if="post.status === 'PUBLISHED'">
      <form @submit.prevent="addComment">
        <label>Add Comment:</label>
        <input v-model="newCommentContent" required />
        <button type="submit">Add Comment</button>
      </form>
    </div>
    <div v-else>
      <p class="warning-message">This post is pending approval. Comments are not allowed.</p>
    </div>

  </div>
</template>

<script>
import postService from '@/services/postService'
import commentService from '@/services/commentService'

export default {
  name: 'PostDetail',
  data() {
    return {
      post: {},
      comments: [],
      isAuthor: false
    }
  },
  methods: {
    fetchPost() {
      const postId = this.$route.params.id
      postService.getPostById(postId)
        .then(resp => {
          this.post = resp.data

          // Verificăm dacă userul logat este autorul postării
          const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));
          this.isAuthor = loggedInUser && loggedInUser === this.post.user.id;
        })
        .catch(err => console.error(err))
    },
    fetchComments() {
      const postId = this.$route.params.id
      commentService.getCommentsForPost(postId)
        .then(resp => {
          this.comments = resp.data
        })
        .catch(err => console.error(err))
    },
    addComment() {
      const postId = this.$route.params.id;
      const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));

      if (!loggedInUser) {
        alert("You must be logged in to comment.");
        return;
      }

      commentService.createComment({
        content: this.newCommentContent,
        userId: loggedInUser,
        postId
      }).then(() => {
        this.newCommentContent = '';
        this.fetchComments();
      }).catch(err => console.error('Error adding comment:', err));
    },
    deletePost() {
      postService.deletePost(this.post.id)
        .then(() => {
          this.$router.push('/posts');
        })
        .catch(err => console.error('Error deleting post:', err))
    }
  },
  mounted() {
    this.fetchPost()
    this.fetchComments()
  }
}
</script>
