<template>
    <div>
      <h2>Edit Comment</h2>
      <form @submit.prevent="updateComment">
        <label>Content:</label>
        <input v-model="comment.content" required />
        <button type="submit">Update</button>
      </form>
    </div>
  </template>
  
  <script>
  import commentService from '@/services/commentService'
  
  export default {
    name: 'CommentEdit',
    data() {
      return {
        comment: {
          content: ''
        }
      }
    },
    methods: {
      fetchComment() {
        // Ai nevoie de un endpoint /comments/:id -> getOne
        // Sau dacă n-ai, evaluează cum îți recuperezi datele:
        // Poți să faci direct la final 'updateComment' cu ce știi
        // Ori aduci datele din alt mod. 
        // Presupunând că ai un getCommentById:
        commentService.getCommentById(this.$route.params.id)
          .then(resp => {
            this.comment = resp.data
          })
          .catch(err => console.error('Error fetching comment', err))
      },
      updateComment() {
        commentService.updateComment(this.$route.params.id, this.comment)
          .then(() => {
            // navighezi înapoi la post 
            // (dar nu știi postId - trebuie să îl fi salvat 
            //   sau să îl extragi cumva, ex. query param)
            this.$router.push('/')
          })
          .catch(err => console.error('Error updating comment', err))
      }
    },
    mounted() {
      this.fetchComment()
    }
  }
  </script>
  