<template>
    <div>
      <h2>Create a New Post</h2>
      <form @submit.prevent="onSubmit">
        <label>Title:</label>
        <input v-model="post.title" required />
  
        <label>Content:</label>
        <textarea v-model="post.content" required></textarea>
  
        <button type="submit">Create</button>
      </form>
    </div>
  </template>
  
  <script>
  import postService from '@/services/postService'
  
  export default {
    name: 'PostCreate',
    data() {
      return {
        post: {
          title: '',
          content: '',
          status: 'PENDING',  // by default
          userId: 1          // sau obții userId-ul din altă parte
        }
      }
    },
    methods: {
      onSubmit() {
        const loggedInUser = JSON.parse(localStorage.getItem("loggedInUser"));
        this.post.userId = loggedInUser;

        postService.createPost(this.post)
          .then(() => {
            this.$router.push('/posts')
          })
          .catch(err => console.error('Error creating post:', err))
      }
    }

  }
  </script>
  