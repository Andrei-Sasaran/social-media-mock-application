<template>
    <div>
      <h2>Published Posts</h2>
      <div v-if="posts && posts.length">
        <ul>
          <li v-for="post in posts" :key="post.id">
            <!-- Link spre detaliile postării -->
            <router-link :to="`/posts/${post.id}`">{{ post.title }}</router-link>
            <!-- Buton de ștergere -->
            <button @click="deletePost(post.id)">Delete</button>
            
          </li>
        </ul>
      </div>
      <div v-else>
        <p>No published posts found.</p>
      </div>
    </div>
  </template>
  
  <script>
import postService from '@/services/postService'

export default {
  name: 'PostList',
  data() {
    return {
      posts: []
    }
  },
  methods: {
    fetchPosts() {
      const loggedInUser = localStorage.getItem("loggedInUser");
      console.log("Logged-in user:", loggedInUser);
      if (!loggedInUser) {
        this.$router.push("/");
        return;
      }

      postService.getAllPublishedPostsForUser(loggedInUser)
        .then(resp => {
          this.posts = resp.data;
        })
        .catch(err => console.error('Error fetching posts:', err))
    },
    deletePost(id) {
      postService.deletePost(id)
        .then(() => {
          this.fetchPosts()
        })
        .catch(err => console.error('Error deleting post:', err))
    }
  },
  mounted() {
    this.fetchPosts()
  }
}
</script>

  