<template>
    <div>
      <h2>Pending Posts</h2>
      <div v-if="posts && posts.length">
        <ul>
          <li v-for="post in posts" :key="post.id">
            <router-link :to="`/posts/${post.id}`">{{ post.title }}</router-link>
            <button @click="deletePost(post.id)">Delete</button>
          </li>
        </ul>
      </div>
      <div v-else>
        <p>No pending posts found.</p>
      </div>
    </div>
  </template>
  
  <script>
import postService from '@/services/postService'

export default {
  name: 'PendingPosts',
  data() {
    return {
      posts: []
    }
  },
  methods: {
    fetchPendingPosts() {
      const loggedInUser = JSON.parse(localStorage.getItem("loggedInUser"));
      if (!loggedInUser) {
        this.$router.push("/");
        return;
      }

      postService.getPendingPostsForUser(loggedInUser)
        .then(resp => {
          this.posts = resp.data;
        })
        .catch(err => console.error('Error fetching pending posts:', err))
    }
  },
  mounted() {
    this.fetchPendingPosts()
  }
}
</script>

  