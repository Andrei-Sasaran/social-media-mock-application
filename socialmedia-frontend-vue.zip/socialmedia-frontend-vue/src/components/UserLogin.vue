<!-- eslint-disable vue/multi-word-component-names -->
<template>
    <div class="login">
      <h2>Login</h2>
      <form @submit.prevent="handleLogin">
        <label for="username">Enter your username:</label>
        <input
          type="text"
          id="username"
          v-model="username"
          placeholder="Enter username"
          required
        />
        <button type="submit">Login</button>
      </form>
      <p v-if="errorMessage" class="error">{{ errorMessage }}</p>
      <button @click="goToRegister">Register</button>
    </div>
  </template>
  
  <script>
  import userService from '@/services/userService'
  
  export default {
    data() {
      return {
        username: "",
        errorMessage: "",
      };
    },
    methods: {
      async handleLogin() {
        const trimmedUsername = this.username.trim();
        if (!trimmedUsername) {
          this.errorMessage = "Username cannot be empty!";
          return;
        }
  
        try {
          const response = await userService.getUserByName(trimmedUsername);
          if (response.data) {
            localStorage.setItem("loggedInUser", JSON.stringify(response.data[0].id));
            this.$router.push("/posts/published"); // Redirect to PostList
          } else {
            this.errorMessage = "User not found!";
          }
        } catch (error) {
          this.errorMessage = "An error occurred. Please try again.";
          console.error(error);
        }
      },
      goToRegister() {
      this.$router.push('/register');
      } 
    },
  };
  </script>
  
  <style scoped>
  .error {
    color: red;
    font-size: 0.9em;
  }
  </style>
  