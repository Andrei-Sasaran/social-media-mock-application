<template>
    <div>
      <h2>All Published Posts</h2>
      <div v-if="posts && posts.length">
        <ul>
          <li v-for="post in posts" :key="post.id">
            <router-link :to="`/posts/${post.id}`">{{ post.title }}</router-link>
          </li>
        </ul>
      </div>
      <div v-else>
        <p>No published posts found.</p>
      </div>
    </div>
  </template>
  
  <script>
  import postService from '@/services/postService'
  
  export default {
    name: 'PublishedPostList',
    data() {
      return {
        posts: []
      }
    },
    methods: {
      fetchPublishedPosts() {
        postService.getAllPosts()
          .then(resp => {
            this.posts = resp.data.filter(post => post.status === 'PUBLISHED')
          })
          .catch(err => console.error('Error fetching posts:', err))
      }
    },
    mounted() {
      this.fetchPublishedPosts()
    }
  }
  </script>
  