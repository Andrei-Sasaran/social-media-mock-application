<template>
    <div>
      <h2>Register</h2>
      <form @submit.prevent="registerUser">
        <label for="name">Name:</label>
        <input id="name" v-model="user.name" required />
  
        <label for="email">Email:</label>
        <input id="email" type="email" v-model="user.email" required />
  
        <button type="submit">Register</button>
      </form>
      <p v-if="message" :class="{ success: success, error: !success }">{{ message }}</p>
  
      <button @click="goToLogin">Back to Login</button>
    </div>
  </template>
  
  <script>
  import userService from '@/services/userService'
  
  export default {
    name: 'UserRegister',
    data() {
      return {
        user: {
          name: '',
          email: ''
        },
        message: '',
        success: false
      }
    },
    methods: {
      async registerUser() {
        try {
          const response = await userService.createUser(this.user);
          if (response.status === 201) {
            this.message = 'User registered successfully!';
            this.success = true;
  
            // Resetare form și navigare înapoi la login după un delay
            setTimeout(() => {
              this.$router.push('/');
            }, 2000);
          }
        } catch (error) {
          this.message = 'Error registering user. Please try again.';
          this.success = false;
          console.error(error);
        }
      },
      goToLogin() {
        this.$router.push('/');
      }
    }
  }
  </script>
  
  <style scoped>
  .success {
    color: green;
  }
  .error {
    color: red;
  }
  </style>
  