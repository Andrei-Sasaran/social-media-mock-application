import { createRouter, createWebHistory } from 'vue-router'
import PostList from './components/PostList.vue'
import PostCreate from './components/PostCreate.vue'
import PostDetail from './components/PostDetail.vue'
import PostUpdate from './components/PostUpdate.vue'
import PostPending from './components/PostPending.vue'
import UserLogin from './components/UserLogin.vue'
import PublishedPostList from './components/PublishedPostList.vue'
import UserRegister from './components/UserRegister.vue'

const routes = [
    { path: '/', name: 'Login', component: UserLogin},
    { path: '/register', name: 'UserRegister', component: UserRegister },
    { path: '/posts', name: 'PostList', component: PostList },
    { path: '/posts/create', name: 'PostCreate', component: PostCreate },
    { path: '/posts/:id', name: 'PostDetail', component: PostDetail },
    { path: '/posts/:id/edit', name: 'PostEdit', component: PostUpdate },
    { path: '/posts/pending', name: 'PendingPosts', component: PostPending},
    { path: '/posts/published', name: 'PublishedPosts', component: PublishedPostList }
]

const router = createRouter({
    history: createWebHistory(),
    routes
})

export default router