<!-- App.vue -->
<template>
  <div id="app">
    <header>
      <h1>Social Media App</h1>
      <nav>
        <!-- Link către pagina principală (lista de postări) -->
        <router-link to="/">Login</router-link> |
        <!-- Link către formularul de creare post -->
        <router-link to="/posts/create">Create Post</router-link> |
        <!-- Link către pagina cu postări pending -->
        <router-link to="/posts/pending">Pending Posts</router-link> |
        <!-- Link catre pagina cu postari publicate-->
        <router-link to="/posts/published">Home</router-link>
      </nav>
    </header>

    <!-- Aici se încarcă componentele în funcție de rută -->
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
/* Stiluri simple de aspect */
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  margin: 20px;
}
nav {
  margin-bottom: 20px;
}
nav a {
  text-decoration: none;
  margin: 0 5px;
}
</style>
