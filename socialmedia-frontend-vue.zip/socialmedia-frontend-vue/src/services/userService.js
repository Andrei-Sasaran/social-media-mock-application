import axios from 'axios'

const API_BASE_URL = '/api/user'

export default {
  getUserByName(username) {
    return axios.get(`${API_BASE_URL}/name/${username}`)
  },
  createUser(userData) {
    return axios.post(`${API_BASE_URL}`, userData); // Endpoint pentru crearea unui utilizator
  }
}
