import axios from 'axios'

const API_BASE_URL = '/api/posts';

export default {
    getAllPosts() {
        return axios.get(`${API_BASE_URL}`)
    },

    getPostById(id) {
        return axios.get(`${API_BASE_URL}/${id}`)
    },

    getAllPublishedPostsForUser(user_id) {
        return axios.get(`${API_BASE_URL}/user/${user_id}/published`);
    },

    getPendingPostsForUser(user_id) {
        return axios.get(`${API_BASE_URL}/user/${user_id}/pending`)
    },
    

    createPost(postData) {
        return axios.post(`${API_BASE_URL}`, postData)
    },

    updatePost(id, updatedData) {
        return axios.put(`${API_BASE_URL}/${id}`, updatedData)
    },

    deletePost(id) {
        return axios.delete(`${API_BASE_URL}/${id}`)
    }
}