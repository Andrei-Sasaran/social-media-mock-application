// services/commentService.js
import axios from 'axios'

const API_URL = '/api/comments';

export default {
  getCommentsForPost(postId) {
    return axios.get(`${API_URL}/post/${postId}`)
  },
  getCommentById(commentId) {
    return axios.get(`${API_URL}/${commentId}`)
  },
  createComment(commentData) {
    return axios.post(`${API_URL}`, commentData)
  },
  updateComment(id, commentData) {
    return axios.put(`${API_URL}/${id}`, commentData)
  },
  deleteComment(id) {
    return axios.delete(`${API_URL}/${id}`)
  }
}
